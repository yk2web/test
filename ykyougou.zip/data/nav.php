<?php
header("Content-Type:text/html");
?>

  <div id="nav_yougou">
    <div id="yougou_logo" class="lf">
     <a href="yougou.html"><img src="images/yougou_logo.png"/></a>
    </div>
    <div id="yougou_search" class="lf">
      <div id="yougou_search_top">
        <form ><input type="text" placeholder="2016冬季热卖" value=""/>
                        <ul id="seachInput">
                        </ul>
          <a class="rt yg_btn" href="#">搜索</a>
        </form>
      </div>
      <div id="yougou_search_remen">
        <ul>
          <li><a href="#">热销</a></li>
          <li><a href="#">跑步鞋</a></li>
          <li><a href="#">乐福鞋</a></li>
          <li><a href="#">徒步鞋</a></li>
          <li><a href="#">衬衣</a></li>
          <li><a href="#">T恤</a></li>
          <li><a href="#">小白鞋</a></li>
          <li><a href="#">2件99起</a></li>
          <li><a href="#">秋款上市</a></li>
          <li><a href="#">专柜同款</a></li>
        </ul>
      </div>
    </div>
    <div id="yougou_buycar" class="rt">
      <div id="yougou_buycar_top"><a href="#">购物车(<b style="color: red">0</b>)件</a><i
        class="down_jiantou"></i></div>
      <div id="yougou_buycar_bottom"><a href="#">百丽旗下的购物网站</a></div>
    </div>
  </div>
  <div id="nav_tittle">
    <div id="tittle_left" class="lf"><h2>全部商品分类</h2>
    </div>
    <div id="tittle_right" class="lf">
      <ul>
        <li><a href="#">运动馆</a></li>
        <li><a href="#">户外鞋</a></li>
        <li><a href="#">鞋靴馆</a></li>
        <li><a href="#">服装馆</a></li>
        <li><a href="#">母婴馆</a></li>
        <li><a href="#">首尔站</a></li>
        <li><a href="#">品牌街</a></li>
        <li><a href="#">聚优购</a></li>
        <li><i></i><a href="#">秒杀</a></li>
      </ul>
    </div>
  </div>

