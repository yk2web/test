<?php
header("Content-Type:text/html");
?>
  <div id="foot_info">

    <p><a href="">关于优购</a> <span> | </span><a href="">品牌招商</a> <span> | </span> <a href="">集团采购</a> <span> | </span> <a href="">招贤纳士</a> <span> | </span> <a href="">手机优购</a> <span> | </span>
      <a href="">联系我们</a> <span> | </span> <a href="">品牌大全</a> <span> | </span> <a href="">网站地图</a> <span> | </span> <a href="">销售排行</a> <span> | </span> <a href="">优购资讯</a> <span> | </span>
      <a href="">网站联盟</a> <span> | </span> <a href="">友情链接</a></p>
    <p>
      Copyright &copy; 2011-2016 Yougou Technology Co., Ltd. <a href="#">粤ICP备09070608号-4</a> 增值电信业务经营许可证： <a
      href="#">粤 B2-20090203</a>
      深公网安备：<a href="">4403101910665</a> <i></i>粤公网安备 <a href="#"> 44030502000017号</a></p>

    <p><img src="images/ebs.png" alt=""/><img src="images/ebs-logo.jpg" alt=""/><img src="images/beian1.png"
                                                                                     alt=""/><img
      src="images/beian2.png" alt=""/></p>
  </div>
