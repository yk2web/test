  <?php
  header("Content-Type:text/html");
  ?>
  <h2>优购导购</h2>
  <div id="item_bom">
    <div id="brand_wall" data-name='1'>

    </div>

    <div id="brand_sort">
      <dl>
        <dt><a href="#">时尚运动</a></dt>
         <dd><a href="#">跑步鞋</a></dd>
        <dd><a href="#">板鞋</a></dd>
        <dd><a href="#">篮球鞋</a></dd>
        <dd><a href="#">T恤</a></dd>
        <dd><a href="#">POLO衫</a></dd>
        <dd><a>更多&gt;&gt;</a></dd>
      </dl>
      <dl>
        <dt><a href="#">流行男鞋</a></dt>
        <dd><a href="#">凉鞋</a></dd>
        <dd><a href="#">乐福鞋</a></dd>
        <dd><a href="#">帆布鞋</a></dd>
        <dd><a href="#">系带</a></dd>
        <dd><a href="#">套脚</a></dd>
        <dd><a href="#">正装</a></dd>
        <dd><a>更多&gt;&gt;</a></dd>

      </dl>
      <dl>
        <dt><a href="#">潮流女鞋</a></dt>
        <dd><a href="#">中空凉鞋</a></dd>
        <dd><a href="#">镂空</a></dd>
        <dd><a href="#">鱼嘴</a></dd>
        <dd><a href="#">平底</a></dd>
        <dd><a href="#">凉拖</a></dd>
        <dd><a href="#">高跟</a></dd>
        <dd><a>更多&gt;&gt;</a></dd>

      </dl>
      <dl>
        <dt><a href="#">童鞋童装</a></dt>
        <dd><a href="#">户外装</a></dd>
        <dd><a href="#">跑步鞋</a></dd>
        <dd><a href="#">板鞋</a></dd>
        <dd><a href="#">卫衣</a></dd>
        <dd><a href="#">裤装</a></dd>
        <dd><a>更多&gt;&gt;</a></dd>

      </dl>
      <dl>
        <dt><a href="#">魅力女装</a></dt>
        <dd><a href="#">连衣裙</a></dt>
        <dd><a href="#">半身裙</a></dd>
        <dd><a href="#">衬衫</a></dd>
        <dd><a href="#">T恤</a></dd>
        <dd><a href="#">短裤</a></dd>
        <dd><a href="#">休闲鞋</a></dd>
        <dd><a>更多&gt;&gt;</a></dd>
      </dl>
      <dl>
        <dt><a href="#">户外休闲</a></dt>
        <dd><a href="#">户外鞋靴</a></dd>
        <dd><a href="#">冲锋衣</a></dd>
        <dd><a href="#">皮肤衣</a></dd>
        <dd><a href="#">T恤</a></dd>
        <dd><a href="#">裤装</a></dd>
        <dd><a>更多&gt;&gt;</a></dd>
      </dl>
      <dl>
        <dt><a href="#">高档箱包</a></dt>
        <dd><a href="#">单肩包</a></dd>
        <dd><a href="#">手提包</a></dd>
        <dd><a href="#">双肩包</a></dd>
        <dd><a href="#">钱包</a></dd>
        <dd><a href="#">手拿包</a></dd>
        <dd><a>更多&gt;&gt;</a></dd>
      </dl>
      <dl>
        <dt><a href="#">精品男装</a></dt>
        <dd><a href="#">T恤</a></dd>
        <dd><a href="#">衬衫</a></dd>
        <dd><a href="#">卫衣</a></dd>
        <dd><a href="#">外套</a></dd>
        <dd><a href="#">牛仔裤</a></dd>
        <dd><a>更多&gt;&gt;</a></dd>
      </dl>

    </div>
  </div>

</div>
<div id="footer_service">
  <ul>
    <li><i></i><a href=""><span>正品</span>保证</a></li>
    <li><i></i><a href=""><span>10天</span>退换货</a></li>
    <li><i></i><a href=""><span>10天调价</span>补差额</a></li>
    <li><i></i><a href=""><span>7&times;24小时</span>在线客服</a></li>
  </ul>
  <div class="foot_help">
    <dl>
      <dt><a href="">新手帮助</a></dt>
      <dd><a href="">交易条款协议</a></dd>
      <dd><a href="">注册新用户</a></dd>
      <dd><a href="">会员积分详情</a></dd>
    </dl>
    <dl>
      <dt><a href="">购物指南</a></dt>
      <dd><a href="">订购详情</a></dd>
      <dd><a href="">验证与收获</a></dd>
      <dd><a href="">订单配送与查询</a></dd>
    </dl>
    <dl>
      <dt><a href="">支付/配送</a></dt>
      <dd><a href="">支付方式</a></dd>
      <dd><a href="">配送方式</a></dd>
      <dd><a href="">配送时间及运费</a></dd>
    </dl>
    <dl>
      <dt><a href="">售后服务</a></dt>
      <dd><a href="">退换票制度</a></dd>
      <dd><a href="">退款说明</a></dd>
      <dd><a href="">发票制度</a></dd>
    </dl>
    <dl>
      <dt><a href="">新手帮助</a></dt>
      <dd><a href="">交易条款协议</a></dd>
      <dd><a href="">注册新用户</a></dd>
      <dd><a href="">会员积分详情</a></dd>
    </dl>
    <dl id="foot_yougou_service">
      <dt>优购客服</dt>
      <dd><i></i><a href="">在线咨询</a></dd>
      <dd>Emial:<span>772967050@qq.com</span></dd>
      <dd>分享购物QQ群:<span>772967050</span></dd>
      <dd>购物微信群:<span>yeke772967050</span></dd>

    </dl>
    <dl id="footer_service_2code">
      <dd><a href="#"><img src="images/footer-mobile-qrcode.jpg" alt=""/></a></dd>
      <dd><a><img src="images/footer-wechat-qrcode.jpg" alt=""/></a></dd>
    </dl>
  </div>

